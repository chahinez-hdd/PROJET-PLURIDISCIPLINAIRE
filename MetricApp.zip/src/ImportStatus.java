
public class ImportStatus {
String ImportName;
int ImportStatus;
ImportStatus(String ImportName,int ImportStatus){
	this.ImportName=ImportName;
	this.ImportStatus=ImportStatus;
}
}
